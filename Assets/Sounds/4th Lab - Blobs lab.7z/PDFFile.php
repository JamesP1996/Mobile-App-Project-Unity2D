<?php
    $var = mysqli_connect("localhost", "root","");
    mysqli_select_db($var, "blobs") or die(mysqli_error());
	$file_id = $_GET['id'];
    $sql = "Select FileDB from blobs where id=$file_id" ;
    $resultset = mysqli_query($var, "$sql") or die("Invalid query: " . mysqli_error());
	$row = mysqli_fetch_array($resultset);
	header('Content-type: application/pdf');
	echo $row[0];
   	mysqli_close($var);
	
?> 


