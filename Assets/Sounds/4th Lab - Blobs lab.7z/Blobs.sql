Drop database if exists Blobs;
Show databases;
create database Blobs;
Use Blobs;
Show tables;
Drop table if exists Blobs;

create table Blobs  (
  id integer auto_increment,
  picture LongBlob,
  picture_path varchar(20),
  video LongBlob,
  video_path varchar(20),
  fileDB LongBlob,
  file_path varchar(20), 
  articleDB Text,
  article_path varchar(20),
  PRIMARY KEY (id)
  ) COLLATE utf8mb4_general_ci, Engine=InnoDB;
  

  
Insert into Blobs values (1, load_file("C:/kittens/flower.jpg"),"/flower.jpg",load_file("C:/kittens/movie.ogg"),"/movie.ogg",load_file("C:/kittens/TEST.pdf"),"/test.pdf", load_file("C:/kittens/Article.html"),"/article.html");
Insert into Blobs values (2, load_file("C:/kittens/flower.jpg"),"/flower.jpg",load_file("C:/kittens/movie.ogg"),"/movie.ogg",load_file("C:/kittens/TEST.pdf"),"/test.pdf", load_file("C:/kittens/Article.html"),"/article.html");
  
